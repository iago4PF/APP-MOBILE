package fr.mypo.messagesauto

class AlertModel (
    val name: String ="WIFI",
    val description : String =" Mot de passe du wifi : 0000",
    val activated: Boolean = false
        )